// Show time-based greeting on homepage
window.onload = () => {
  const hours = new Date().getHours();
  let greeting = "Hello";
  if (hours < 12) greeting = "Good morning";
  else if (hours < 18) greeting = "Good afternoon";
  else greeting = "Good evening";
  const greetingElement = document.getElementById("greeting");
  if (greetingElement) {
      greetingElement.innerText = `${greeting}, welcome to Senotrams!`;
  }
};

// Toggle project details (used in projects.html)
function toggleDetails(card) {
  const detail = card.querySelector("p");
  if (detail) {
      detail.classList.toggle("hidden");
  }
}

// Validate the contact form (used in contact.html) with real-time feedback
document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.querySelector('form');
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");
  const emailError = document.getElementById("email-error");
  const phoneError = document.getElementById("phone-error");
  const emailRegex = /^[^@\\s]+@[^@\\s]+\.[^@\\s]+$/;
  const phoneRegex = /^[0-9]{7,15}$/;

  if (emailInput && phoneInput && emailError && phoneError && contactForm) {
      emailInput.addEventListener('input', validateEmail);
      phoneInput.addEventListener('input', validatePhone);
      contactForm.addEventListener('submit', (event) => {
          if (!validateForm()) {
              event.preventDefault();
          }
      });
  }

  function validateEmail() {
      const email = emailInput.value.trim();
      if (!emailRegex.test(email)) {
          emailError.textContent = "Please enter a valid email address.";
          emailInput.classList.add("invalid");
          return false;
      } else {
          emailError.textContent = "";
          emailInput.classList.remove("invalid");
          return true;
      }
  }

  function validatePhone() {
      const phone = phoneInput.value.trim();
      if (!phoneRegex.test(phone)) {
          phoneError.textContent = "Please enter a valid phone number (digits only).";
          phoneInput.classList.add("invalid");
          return false;
      } else {
          phoneError.textContent = "";
          phoneInput.classList.remove("invalid");
          return true;
      }
  }

  function validateForm() {
      return validateEmail() && validatePhone();
  }
});